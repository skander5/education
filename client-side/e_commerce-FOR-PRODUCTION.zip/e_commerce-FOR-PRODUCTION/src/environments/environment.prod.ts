export const environment = {
  production: true,
  apibaseUrl : 'https://purchase-apl.herokuapp.com/Ecommerce/servlet'

};
