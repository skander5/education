import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-command',
  templateUrl: './list-command.component.html',
  styleUrls: ['./list-command.component.css']
})
export class ListCommandComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
